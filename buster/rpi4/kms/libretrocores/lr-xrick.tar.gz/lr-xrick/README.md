xrick
=====

Xrick is an open source implementation of the legendary game "Rick Dangerous".

Based on BigOrno (bigorno@bigorno.net)'s work (http://www.bigorno.net/xrick/).
I added and XCode project and the game now runs on MacOS X Maverick.

Platforms 
=========

Windows, MacOS X and Linux

Dependencies 
============

SDL 1.2

Enjoy,

Fabien
