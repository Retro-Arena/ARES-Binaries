#!/usr/bin/env bash
export ALSOFT_DRIVERS="-jack,"
ARGS=("-fullscreen=yes" "-cursor-visible=no" "-lua-console=no")
[[ -f "/opt/ares/configs/solarus/options.cfg" ]] && source "/opt/ares/configs/solarus/options.cfg"
[[ -n "$JOYPAD_DEADZONE" ]] && ARGS+=("-joypad-deadzone=$JOYPAD_DEADZONE")
[[ -n "$QUIT_COMBO" ]] && ARGS+=("-quit-combo=$QUIT_COMBO")
if false; then
  if [[ -f /opt/vc/lib/libbrcmGLESv2.so ]]; then
    export LD_PRELOAD="/opt/vc/lib/libbrcmGLESv2.so"
  fi
fi
exec "/opt/ares/emulators/solarus"/bin/solarus-run "${ARGS[@]}" "$@"
