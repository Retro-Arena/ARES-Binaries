#!/bin/bash

#Festival script filter to use default language

cat | festival --tts 
