#!/bin/bash
# HACK: force vsync for RPI Mesa driver for now
VC4_DEBUG=always_sync /opt/ares/ports/eduke32/eduke32 $*
