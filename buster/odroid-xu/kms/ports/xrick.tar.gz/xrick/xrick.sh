#!/bin/bash
pushd "/opt/ares/ports/xrick"
./xrick "$@"
popd
