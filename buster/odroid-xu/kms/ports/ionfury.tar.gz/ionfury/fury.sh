#!/bin/bash
# HACK: force vsync for RPI Mesa driver for now
VC4_DEBUG=always_sync /opt/ares/ports/ionfury/fury $*
