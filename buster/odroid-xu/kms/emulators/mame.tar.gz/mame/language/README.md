# **Translations** #

Translation files contains work of many authors used to localize MAME to more languages.

Licensed under [CC0 1.0 Universal (CC0 1.0)](https://creativecommons.org/publicdomain/zero/1.0/)