#!/bin/bash
pushd "/home/aresuser/ARES/roms/apple2"
/opt/ares/emulators/linapple/linapple "$@"
popd
