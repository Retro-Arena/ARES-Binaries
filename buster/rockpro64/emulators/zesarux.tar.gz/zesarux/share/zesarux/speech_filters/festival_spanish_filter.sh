#!/bin/bash

#Festival script filter to use Spanish Language

cat | festival --tts --language spanish

