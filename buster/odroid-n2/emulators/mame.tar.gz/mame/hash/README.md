# **Software Lists** #

Software lists are containing meta-data of software for computers and consoles and are coming from various sources,
they are not compiled in code but use as valuable source of information in order to preserve and document software.

Licensed under [CC0 1.0 Universal (CC0 1.0)](https://creativecommons.org/publicdomain/zero/1.0/)
