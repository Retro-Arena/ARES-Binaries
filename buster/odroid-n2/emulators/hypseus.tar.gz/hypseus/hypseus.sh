#!/bin/bash
dir="$1"
name="${dir##*/}"
name="${name%.*}"

if [[ -f "$dir/$name.commands" ]]; then
    params=$(<"$dir/$name.commands")
fi

"/opt/ares/emulators/hypseus/hypseus" "$name" vldp -framefile "$dir/$name.txt" -homedir "/opt/ares/emulators/hypseus" -fullscreen -x 1920 -y 1080 -useoverlaysb 2   $params
