#!/bin/bash

say -f -
