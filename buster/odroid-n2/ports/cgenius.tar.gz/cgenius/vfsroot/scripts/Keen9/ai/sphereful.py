def isStunnableWithPogo():
    # Can Keen stun the enemy with pogo alone?
    return False


def isInvincible():
    # isInvincible. Shots never kill it
    return False


def willNeverStop():
    # willNeverStop. Robo red will continue chasing and shoot wherever required
    return True

