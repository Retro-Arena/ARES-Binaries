#!/bin/bash

#echo "Deteniendo proceso speech"


killall espeak > /dev/null 2>&1
