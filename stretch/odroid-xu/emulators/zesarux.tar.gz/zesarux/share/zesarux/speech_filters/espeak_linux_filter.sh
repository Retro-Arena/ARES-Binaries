#!/bin/bash

#eSpeak script filter to use default language

cat | espeak --stdin
