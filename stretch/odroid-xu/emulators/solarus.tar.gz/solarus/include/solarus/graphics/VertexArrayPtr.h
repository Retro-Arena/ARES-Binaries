#pragma once

#include <memory>
namespace Solarus {

class VertexArray;

using VertexArrayPtr = std::shared_ptr<VertexArray>;

}
