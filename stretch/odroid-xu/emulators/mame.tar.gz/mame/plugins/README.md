# **Plugins** #

LUA plugins contains code from various sources so license is per file.
