Programming
	Alec "Aloshi" Lofquist - http://www.aloshi.com

UI Art & Design
	Nils Bonenberger


Libraries
=========

PugiXML
	http://pugixml.org/

SDL 2
	http://www.libsdl.org/

FreeImage
	http://www.freeimage.sourceforge.net

FreeType
	http://www.freetype.org

cURL
	http://curl.haxx.se/

nanosvg
	https://github.com/memononen/nanosvg

Resources
=========

Open Sans font
	http://www.google.com/fonts/specimen/Open+Sans