def StartLoadScreen():
	pass

def SetLoadScreen():
	pass
