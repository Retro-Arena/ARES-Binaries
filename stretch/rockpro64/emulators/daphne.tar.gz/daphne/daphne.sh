#!/bin/bash
dir="$1"
name="${dir##*/}"
name="${name%.*}"

if [[ -f "$dir/$name.commands" ]]; then
    params=$(<"$dir/$name.commands")
fi

"/opt/ares/emulators/daphne/daphne.bin" "$name" vldp -nohwaccel -framefile "$dir/$name.txt" -homedir "/opt/ares/emulators/daphne" -fullscreen -x 1920 -y 1080 $params
