#!/usr/bin/env bash
export ALSOFT_DRIVERS="-jack,"
ARGS=("-cursor-visible=no" "-fullscreen=yes")
[[ -f "/opt/ares/configs/solarus/options.cfg" ]] && source "/opt/ares/configs/solarus/options.cfg"
[[ -n "$JOYPAD_DEADZONE" ]] && ARGS+=("-joypad-deadzone=$JOYPAD_DEADZONE")
[[ -n "$QUIT_COMBO" ]] && ARGS+=("-quit-combo=$QUIT_COMBO")
"/opt/ares/emulators/solarus"/bin/solarus-run "${ARGS[@]}" "$@"
