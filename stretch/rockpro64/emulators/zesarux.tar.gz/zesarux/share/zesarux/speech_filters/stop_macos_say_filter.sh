#!/bin/bash

#echo "Deteniendo proceso speech"


killall say > /dev/null 2>&1
